1. Copy and run the contents of database file in your MySQL Workbench
2. Open Databases.java file in src/main/java and change "root" to your MySQL Workbench username and "Panwala@44" to your MySQL Workbench password and save the file.
3. Open MyController.java file in src/main/jain and change "root" to your MySQL Workbench username and "Panwala@44" to your MySQL Workbench password and save the file.
4. Copy the address of the folder where you save the project.
5. Open cmd and type "cd paste" and hit enter without quotes where paste means the address of the project folder.
6. Type "mvn compile exec:java" and hit enter without quotes.
7. The application GUI will start with log in scene.