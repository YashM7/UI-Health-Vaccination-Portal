import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.sql.*;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.Node;

public class MyController implements Initializable {

//-------------------------------------------------------------------------------------------------
//start log_in_scene		
	
	
	@FXML
	private VBox root;
	
	@FXML
	private BorderPane root2;
    
    @FXML
    private TextField textField;
    
    @FXML
    private TextField userField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button login;
    
    @FXML
    private Button admin;

    @FXML
    private Button nurse;

    @FXML
    private Button patient;
    
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    
    @FXML
    void type(ActionEvent event) {
    	try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project4", "root", "Boruto$100");
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("SELECT * FROM project4.log_in;");
			while (rs.next()) {
				System.out.println(rs.getString(1));
			}
			infoBox_ERROR("Incorrect username or password.",null,"Access Denied");
			con.close();
		} catch(Exception e) {
			System.out.println(e);
		}
    }
    
    public static void infoBox_ERROR(String infoMessage, String headerText, String title){
        Alert alert = new Alert(AlertType.ERROR);
        alert.setContentText(infoMessage);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.showAndWait();
    }
    
    public static void infoBox_WARNING(String infoMessage, String headerText, String title){
        Alert alert = new Alert(AlertType.WARNING);
        alert.setContentText(infoMessage);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.showAndWait();
    }
    
    @FXML
    void check(ActionEvent event) {
    	userField.setText("Enter user ID: ???");
    }
    
    @FXML
    void New_Patient_Sign_Up(ActionEvent event) throws IOException {
    	System.out.println("Admin Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene_sign_up.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Registration Portal");
    	window.show();
    }
    
    @FXML
    void log_in_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Admin Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
//end log_in
//-------------------------------------------------------------------------------------------------    

    
    

    
//-------------------------------------------------------------------------------------------------
//start Admin
    
    
    
    @FXML
    private Button reg_nur;
    
    @FXML
    private Button admin_log_out;

    @FXML
    private Button update_nurse;

    @FXML
    private Button delete_nurse;

    @FXML
    private Button add_vaccine;

    @FXML
    private Button update_vaccine;

    @FXML
    private Button view_nurse_info;

    @FXML
    private Button view_patient_info;
    
    @FXML
    void reg_nur_action(ActionEvent event) throws IOException {
    	System.out.println("Register Button pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin_register_a_nurse.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse Registration Portal");
    	window.show();
    }
    
    @FXML
    void update_nurse_action(ActionEvent event) throws IOException {
    	System.out.println("Update Nurse Button pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin_update_nurse_info.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Update Nurse Information Portal");
    	window.show();
    }
    
    @FXML
    void delete_nurse_action(ActionEvent event) throws IOException {
    	System.out.println("Delete Nurse Button pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin_delete_a_nurse.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Delete Nurse Portal");
    	window.show();
    }
    
    @FXML
    void add_vaccine_action(ActionEvent event) throws IOException {
    	System.out.println("Add Vaccine Button pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin_add_vaccine.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Add Vaccine Portal");
    	window.show();
    }
    
    @FXML
    void update_vaccine_action(ActionEvent event) throws IOException {
    	System.out.println("Update Vaccine Button pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin_update_vaccine.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Update Vaccine Portal");
    	window.show();
    }
    
    @FXML
    void view_nurse_info_action(ActionEvent event) throws IOException {
    	System.out.println("View Nurse Info Button pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin_view_nurse_info.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("View Nurse Information Portal");
    	window.show();
    }

    @FXML
    void view_patient_info_action(ActionEvent event) throws IOException {
    	System.out.println("View Patient Info Button pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin_view_patient_info.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("View Patient Information Portal");
    	window.show();
    }
    
    @FXML
    void admin_log_out(ActionEvent event) throws IOException {
    	System.out.println("Admin Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    

//-------------------------------------------------------------------------------------------------------
//start Admin_register_a_nurse
    
    
    
    @FXML
    private TextField emp_id;

    @FXML
    private TextField fname;

    @FXML
    private TextField mname;

    @FXML
    private TextField lmane;

    @FXML
    private TextField gen;

    @FXML
    private TextField age;

    @FXML
    private TextField phno;

    @FXML
    private TextField add;

    @FXML
    private TextField uname;

    @FXML
    private PasswordField pw;
    
    @FXML
    private Button register_go_back;

    @FXML
    private Button register_log_out;

    @FXML
    void register_go_back_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Admin Portal");
    	window.show();
    }

    @FXML
    void register_log_out_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    @FXML
	void submit_nurse_reg(ActionEvent event) throws IOException{
		String fir_name, mid_name, la_name,  addy, g, user, pass;
		int id, a;
		long ph;
		id = Integer.parseInt(emp_id.getText());
		fir_name = fname.getText();
		mid_name = mname.getText();
		la_name = lmane.getText();
		addy = add.getText();
		ph = Long.parseLong(phno.getText());
		g = gen.getText();
		a = Integer.parseInt(age.getText());
		user = uname.getText();
		pass = pw.getText();
//		Databases.registerNurse(id, fir_name, mid_name, la_name,  addy, ph, String.valueOf(g.charAt(0)), a, user, pass);
	}
    
    
    
//end Admin_register_a_nurse
//---------------------------------------------------------------------------------------------------    

    
    
    
    
//-------------------------------------------------------------------------------------------------------
//start Admin_update_nurse    
    
    
    @FXML
    private TextField uemp;

    @FXML
    private TextField ufname;

    @FXML
    private TextField umname;

    @FXML
    private TextField ulname;

    @FXML
    private TextField ugen;

    @FXML
    private TextField uage;

    @FXML
    private TextField uuser;

    @FXML
    private PasswordField upw;
    
    @FXML
    private Button update_nurse_go_back;

    @FXML
    private Button update_nurse_log_out;

    @FXML
    void update_nurse_go_back_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Admin Portal");
    	window.show();
    }

    @FXML
    void update_nurse_log_out_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
//end Admin_update_nurse
//-------------------------------------------------------------------------------------------------------

    
    
    
    
//-----------------------------------------------------------------------------------------------------
//start delete_nurse
    
    
    @FXML
    private TextField delete_nurse_text;
    
    @FXML
    private Button delete_nurse_log_out;

    @FXML
    private Button delete_nurse_go_back;
    
    @FXML
    void delete_nurse(ActionEvent event) {

    }

    @FXML
    void delete_nurse_go_back_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Admin Portal");
    	window.show();
    }

    @FXML
    void delete_nurse_log_out_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
  
    
    
//end delete_nurse
//-----------------------------------------------------------------------------------------------------    

    
    
    
    
//-----------------------------------------------------------------------------------------------------
//start add_vaccine
    
    @FXML
    private TextField vcom;

    @FXML
    private TextField vname;

    @FXML
    private TextField vnum;

    @FXML
    private Button add_vac;

    @FXML
    private Button add_vaccine_log_out;

    @FXML
    private Button add_vaccine_go_back;

    @FXML
    private TextField vavail;

    @FXML
    private TextField vhold;

    @FXML
    private TextField vdesc;

    @FXML
    void add_vac_action(ActionEvent event) {

    }


    @FXML
    void add_vaccine_go_back_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Admin Portal");
    	window.show();
    }

    @FXML
    void add_vaccine_log_out_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
    
    
//end add_vaccine
//-----------------------------------------------------------------------------------------------------

    
    
//-----------------------------------------------------------------------------------------------------
//start update_vaccine    
    
    
    @FXML
    private TextField vname2;

    @FXML
    private TextField numd;

    @FXML
    private Button update_vaccine_log_out;

    @FXML
    private Button update_vaccine_go_back;

    @FXML
    void update_rep(ActionEvent event) {

    }

    @FXML
    void update_vaccine_go_back_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Admin Portal");
    	window.show();
    }

    @FXML
    void update_vaccine_log_out_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
    
//end update_vaccine        
//-----------------------------------------------------------------------------------------------------
   
 
    
//-----------------------------------------------------------------------------------------------------
//start view_nurse_info
    
    
    @FXML
    private TextField view_nurse;

    @FXML
    private Button view_nurse_log_out;

    @FXML
    private Button view_nurse_go_back;

    @FXML
    private TextArea textarea;

    @FXML
    void view_nurse_action(ActionEvent event) {

    }

    @FXML
    void view_nurse_go_back_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Admin Portal");
    	window.show();
    }

    @FXML
    void view_nurse_log_out_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
    
//end view_nurse_info            
//-----------------------------------------------------------------------------------------------------
  
    

    
    
//-----------------------------------------------------------------------------------------------------
//start view_patient_info
    
    
    @FXML
    private Button view_patient_info_log_out;

    @FXML
    private Button view_patient_info_go_back;
    
    @FXML
    private TextArea ptextarea;

    @FXML
    void view_patient_info_go_back_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Admin.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Admin Portal");
    	window.show();
    }

    @FXML
    void view_patient_info_log_out_action(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
 
//-----------------------------------------------------------------------------------------------------
//end view_patient_info    
    
    
    
    
//end Admin
//-------------------------------------------------------------------------------------------------    

    
    

    
//-------------------------------------------------------------------------------------------------    
//start Nurse
    
    
    
    @FXML
    private Button nurse_log_out;

    @FXML
    void nurse_log_out(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    @FXML
    void nurse_update_information_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Nurse_update_information.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse Update Information Portal");
    	window.show();
    }
    
    @FXML
    void nurse_cancel_time_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Nurse_cancel_time.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse Cancel Time Portal");
    	window.show();
    }


    @FXML
    void nurse_schedule_time_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Nurse_schedule_time.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse Schedule Time Portal");
    	window.show();
    }


    @FXML
    void nurse_vaccination_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Nurse_vaccination.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse Vaccination Record Portal");
    	window.show();
    }

    @FXML
    void nurse_view_information_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Nurse_view_information.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse View Information Portal");
    	window.show();
    }
    
    
    
    
//-----------------------------------------------------------------------------------------------
//start Nurse_update_information
    
    
    @FXML
    private Button nurse_update_info_go_back;

    @FXML
    private Button nurse_update_info_log_out;
    
    @FXML
    void nurse_update_info_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Nurse.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse Portal");
    	window.show();
    }

    @FXML
    void nurse_update_info_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    

//end Nurse_update_information
//-----------------------------------------------------------------------------------------------

      
//-----------------------------------------------------------------------------------------------
//start schedule time    
    
    @FXML
    void nurse_schedule_time_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Nurse.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse Portal");
    	window.show();
    }

    @FXML
    void nurse_schedule_time_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }


    
    
//end schedule time    
//-----------------------------------------------------------------------------------------------

    
//-----------------------------------------------------------------------------------------------
//start cancel time
    
    @FXML
    void nurse_cancel_time_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Nurse.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse Portal");
    	window.show();
    }

    @FXML
    void nurse_cancel_time_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
//end cancel time    
//-----------------------------------------------------------------------------------------------    


//-----------------------------------------------------------------------------------------------
//start view information
    
    @FXML
    void nurse_view_information_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Nurse.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse Portal");
    	window.show();
    }

    @FXML
    void nurse_view_information_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
    
//end view information   
//-----------------------------------------------------------------------------------------------    


//-----------------------------------------------------------------------------------------------
//start vaccination
    
    @FXML
    void nurse_vaccination_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Nurse.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Nurse Portal");
    	window.show();
    }

    @FXML
    void nurse_vaccination_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Nurse Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
    
    
//end vaccination
//-----------------------------------------------------------------------------------------------
    
    
//end Nurse    
//-----------------------------------------------------------------------------------------------   
    
    
//-----------------------------------------------------------------------------------------------
//start Patient
    

    @FXML
    void patient_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    @FXML
    void patient_register_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Patient_register.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Registration Portal");
    	window.show();
    }
    
    @FXML
    void patient_cancel_schedule_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Patient_cancel_schedule.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Registration Portal");
    	window.show();
    }


    @FXML
    void patient_schedule_vaccination_time_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Patient_schedule_vaccine.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Registration Portal");
    	window.show();
    }

    @FXML
    void patient_update_information_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Patient_update_info.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Registration Portal");
    	window.show();
    }

    @FXML
    void patient_view_patient_info_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Patient_view_information.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Registration Portal");
    	window.show();
    }

    
    
    
    
//-----------------------------------------------------------------------------------------------
//start patient register
    
    @FXML
    void patient_register_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Patient.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Portal");
    	window.show();
    }

    @FXML
    void patient_register_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
//end Patient   
//-----------------------------------------------------------------------------------------------    
 

    
    
//-----------------------------------------------------------------------------------------------
//start update patient info    
    
    @FXML
    void patient_update_info_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Patient.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Portal");
    	window.show();
    }

    @FXML
    void patient_update_info_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
  
    
//end update patient info    
//----------------------------------------------------------------------------------------------    
 
    
    
    
    
//-----------------------------------------------------------------------------------------------
//start patient schedule vaccine
    
    @FXML
    void patient_schedule_vaccine_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Patient.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Portal");
    	window.show();
    }

    @FXML
    void patient_schedule_vaccine_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
    
    
//end patient schedule vaccine 
//----------------------------------------------------------------------------------------------
    

    
    
//-----------------------------------------------------------------------------------------------
//start patient cancel schedule    
    
    @FXML
    void patient_cancel_schedule_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Patient.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Portal");
    	window.show();
    }

    @FXML
    void patient_cancel_schedule_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
    
//end patient cancel schedule
//----------------------------------------------------------------------------------------------
 
    

//-----------------------------------------------------------------------------------------------
//start view information
    
    @FXML
    void patient_view_patient_info_go_back_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/Patient.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("Patient Portal");
    	window.show();
    }

    @FXML
    void patient_view_patient_info_log_out_action(ActionEvent event) throws IOException {
    	System.out.println("Patient Log Out pressed");
    	Parent root = FXMLLoader.load(getClass().getResource("/FXML/log_in_scene.fxml"));
    	Scene log_in_scene = new Scene(root);
    	Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
    	window.setScene(log_in_scene);
    	window.setTitle("UI Health Vaccination Login Portal");
    	window.show();
    }
    
    
    
//end view information   
//----------------------------------------------------------------------------------------------

    
//end Patient    
//----------------------------------------------------------------------------------------------    
    
    
    
    @Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
        
	}
	
	
	public void bill(ActionEvent e) throws IOException{
		System.out.println("Bill button pressed, generating bill...");
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/Myfxml2.fxml"));
        Parent root2 = loader.load(); //load view into parent
        MyController myctr = loader.getController();//get controller created by FXMLLoader
        
        root2.getStylesheets().add("/styles/style2.css");//set style
        
        root.getScene().setRoot(root2);//update scene graph
	}
	
	public void make_another(ActionEvent e) throws IOException{
		System.out.println("Make another button pressed");
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/Myfxml.fxml"));
        Parent root = loader.load();
        MyController myctr = loader.getController();
        root2.getScene().setRoot(root);
	}
	
	public void exit(ActionEvent e) throws IOException{
		System.out.println("Exit button pressed");
	}

}